#include <iostream>
#include <stack.h>

using namespace std;

const uint16_t
    IS_FILLED_IN = 0x8000,
    VALID_MASK = 0x7fc0,
    NUM_MASK = 0x000f;

Stack<int>
    cells;

uint16_t
    board[9][9];

int main() {

    // input the board
    // loop over all rows
        // loop over all cols
            // read one value
            // if it's a dot, set board[i][j] to 0
            // else, set board[i][j] to IS_FILLED_IN | (value - '0')

    // use solve() to solve the puzzle

    // output solved puzzle (or claim it's unsolvable)

    return 0;
}
