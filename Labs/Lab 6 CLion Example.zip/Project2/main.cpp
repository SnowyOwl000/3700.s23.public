#include <iostream>
#include <stack.h>

using namespace std;

int main() {
    Stack<int>
        myStack;

    myStack.push(1);
    myStack.push(2);
    myStack.push(3);

    while (!myStack.isEmpty()) {
        cout << myStack.pop() << endl;
    }

    return 0;
}
